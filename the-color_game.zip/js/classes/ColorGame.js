class ColorGame {
    constructor(difficulty, stage) {
       this.difficulty = difficulty;
       this.stage = stage;
       // todo: create lists of colors, theColor, etc.
    }

    reset() {
        alert("not working yet... but when it is, it will be " + this.difficulty);
    }
}
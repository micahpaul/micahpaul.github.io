# Requirements for The Game
* still a color game
* cool animations
  * background
  * on selection
* 3D
* limited scope
  * only x (20?) rounds
* more suspense
  * intense music
  * take damage based on time
* increasing difficulty
  * more than 3 colors
  * colors are closer
* color targets: words? symbols?
* create secondary colors
* see mockup image for first draft design

## Game flow
* multiple choice of color
* correct: reward
* incorrect: punished